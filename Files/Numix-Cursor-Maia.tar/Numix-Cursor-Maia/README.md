# Numix-Cursor-Maia

Maia Colored Numix Cursor theme

# Preview

<p align="center">
<img src="https://s19.postimg.cc/4fgirxvpv/Screenshot_2017-12-13_17-52-39.png" width="200px" /> <img src="https://forum.manjaro.org/uploads/default/original/2X/3/31bf9adcf08f997cf81c4f1c02b9097efb954de5.png" width="150px" /> <img src="https://s19.postimg.cc/ub09b559f/Screenshot_2017-12-13_17-53-09.png" width="200px" /> 
</p>

# Installation

``` 
git clone https://github.com/mustafaozhan/Numix-Cursor-Maia.git && cd Numix-Cursor-Maia && chmod +x install.sh && sh install.sh

```
- Arch Linux user's
```
yaourt -S numix-cursor-maia-git
```
# Thanks to
 
This cursor theme modified version of <a href="https://github.com/numixproject/numix-cursor-theme">numix-cursor-theme</a>
 

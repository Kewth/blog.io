#!/bin/bash
sudo mkdir /usr/share/icons/Numix-Cursor-Maia;
sudo mv * /usr/share/icons/Numix-Cursor-Maia;
cd ..;
rm -rf Numix-Cursor-Maia;
